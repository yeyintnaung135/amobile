@extends('backend.layout.app')
@section('title','A Mobile | Product Create')
@push('style')
    <style>
      .upload{
            display: inline-block;
            background-color: #17a2b8;
            color: white;
            padding: 0.5rem;
            font-family: sans-serif;
            border-radius: 0.3rem;
            cursor: pointer;
            /* margin-top: 1rem; */
          }
        .cat-show-img{
            width: 100px !important;
            height: 100px !important;
        }
        .cat-img{
            width: 80px !important;
        }
    </style>
@endpush
@section('content')
    <div class="container-fluid">
        <div class="row d-flex justify-content-center">
            <div class="col-12  mt-2">
                   <!-- card start  -->
                   <div class="card w-100 border-0 shadow-none">
                    <div class="card-header">
                       <div class="d-flex justify-content-between w-100">
                          <div class="card-title">Create color</div>
                          <div class=""><a href="{{ route('store_admin.product.list')}}"><i class="fas fa-list"></i></a></div>
                       </div>
                    </div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="col-12 col-lg-6 p-3 ">
                                <div class="form-group mb-5">
                                    <label for="productColor">Name</label>
                                    <input type="text" name="name" class="form-control @error('name')
                                            is-invalid
                                        @enderror" id="productColor">
                                        @error('name')
                                        <span class="font-weight-bolder text-danger">{{ $message}}</span>
                                        @enderror
                                </div>
                                <div class="form-group">
                                    <label for="productName">Upload Image</label>
                                    <div class="form-row">
                                        <div class="w-50 col-3">
                                         <img src="{{ asset( 'images/assets/default-image.png') }}" id="uploaded_image" class="cat-show-img mb-2" alt="Category Image"/>
                                        </div>
                                        <div class="ml-3 col-6 col-lg-4">
                                         <input type="file" id="upload_image" hidden/>
                                          <label for="upload_image" class="upload rounded-0">Upload Image</label>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- col-end -->
                            <div class="col-12 col-lg-6 p-3">
                                <table class="table">
                                    <thead>
                                        <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Image</th>
                                        <!-- <th scope="col">Handle</th> -->
                                        </tr>
                                    </thead>
                                    @php
                                        $id = 1;
                                    @endphp
                                    <tbody>
                                        @forelse ($colors as $color)
                                            <tr>
                                                <th scope="col">{{ $id++}}</th>
                                                <th scope="col">{{ $color->name }}</th>
                                                <th scope="col">
                                                    <img src="{{ asset($color->image)}}" alt="" class="w-25">
                                                </th>
                                                <!-- <th scope="col">Handle</th> -->
                                            </tr>
                                        @empty
                                            
                                        @endforelse
                                      
                                    </tbody>
                                </table>
                            </div>
                          
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary" id="createColor">Create</button>
                        </div>
                    </div> <!---- Card Body end --->
                </div>
                <!-- card end  -->
            </div>
        </div>
    </div>
@endsection
@push('script')
    <script>
          let base64Data = [];
          $("#upload_image").change(function(event){
               var files = event.target.files;
               var image = document.getElementById('uploaded_image');

               var done = function(url){
                   image.src = url;

               }
               if (files && files.length > 0){
      
                  reader = new FileReader();
                  reader.onload = function (event) {
                    done(reader.result);
                    base64Data.push(reader.result);
                  };
                  reader.readAsDataURL(files[0]);
                }    
               
        });

        $("#createColor").click(function(e){
            console.log(base64Data)
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })
          e.preventDefault();
          var formData = {
                name: jQuery("input[name=name]").val(),
                image: base64Data,
            }
         
          $.ajax({
                url: "{{ route('store_admin.color.store') }}",
                method: "POST",   
                cache: false,             	
                data: formData,
                error:function(err){
                //console.log(err.responseText)
                    console.warn(err.responseJSON.errors);
                    
                },
                success:function(response){
                    if(response.success){
                        alert(response.message);
                    }else{
                        alert("Error");
                    }
                    window.location.reload();
                },

              });
        })

    </script>
@endpush