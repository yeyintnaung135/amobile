@extends('backend.layout.app')
@section('title','Amobile | Dashboard')
@section('content')

    
@endsection




