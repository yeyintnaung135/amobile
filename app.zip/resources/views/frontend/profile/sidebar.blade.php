<div class="card">
    <div class="card-body">
        <div class="col-12 mb-4">
            <div class="w-100 d-flex justify-content-center mb-3">
                <div class="profile border rounded-circle">
                <img src="{{ asset('images/assets/default-profile.png')}}" class="w-100" alt="">
                </div>
            </div>
            <h3 class="text-center">{{ Auth::user()->name }}</h3>
        </div>
        <div class="col-12 mb-2 d-flex justify-content-center">
            <div class="d-flex bg-smoke justify-content-between w-100 rounded-1 mb-2">
                <div class="p-3 align-items-center d-flex justify-content-around">
                <i class="far fa-user"></i>
                <a href="{{ route('home')}}"><span class="ml">My Profile</span></a>
                </div>
                <div class="p-3">
                <i class="fas fa-angle-right"></i>
                </div>
            </div>
        </div>
        <div class="col-12 mb-2 d-flex justify-content-center">
            <div class="d-flex bg-smoke justify-content-between w-100 rounded-1 mb-2">
                <div class="p-3 d-flex align-items-center">
                <i class="fas fa-cart-plus"></i>
                <span class="ml">Orders</span>
                </div>
                <div class="p-3">
                <i class="fas fa-angle-right"></i>
                </div>
            </div>
        </div>
        <div class="col-12 mb-2 d-flex justify-content-center">
            <div class="d-flex bg-smoke justify-content-between w-100 rounded-1 mb-2">
                <div class="p-3 d-flex align-items-center">
                    <i class="far fa-heart"></i>
                   <a href="{{ route('wishlist')}}"> <span class="ml">Wishlist</span></a>
                </div>
                <div class="p-3">
                   <i class="fas fa-angle-right"></i>
                </div>
            </div>
        </div>
        <div class="col-12 mb-2 d-flex justify-content-center">
            <div class="d-flex bg-smoke justify-content-between w-100 rounded-1 mb-2">
                <div class="p-3 d-flex align-items-center">
                <i class="fas fa-map-marker-alt"></i>
                <a href="{{ route('billing_address')}}"><span class="ml">Billing Address</span></a>
                </div>
                <div class="p-3">
                <i class="fas fa-angle-right"></i>
                </div>
            </div>
        </div>
        <div class="col-12 mb-2 d-flex justify-content-center">
            <div class="d-flex bg-smoke justify-content-between w-100 rounded-1 mb-2">
                <div class="p-3 d-flex align-items-center">
                <i class="far fa-eye"></i>
                <a href="{{ route('change_password')}}"> <span class="ml">Change Password</span></a>
                </div>
                <div class="p-3">
                <i class="fas fa-angle-right"></i>
                </div>
            </div>
        </div>
    </div>
</div>